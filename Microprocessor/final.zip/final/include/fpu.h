#ifndef __FPU_H__
#define __FPU_H__
void FPU__enable();
#endif